package coe528;

public class ParkingSpots {
    
  public String Vehicleid;
  public String VehicleType;
  public Ticket ticket;
  
  //putting vehicleid and vehicletype in the variables
  public ParkingSpots(String Vehicleid, String Vehicletype){
    this.Vehicleid = Vehicleid;
    this.VehicleType = Vehicletype;
     this.ticket = null;
  }
  
  //Adding the end time for the purchased ticket, adding the price for the ticket and getting ticket number
  public void closeTicket(int endTime){
        this.ticket.setEndTime(endTime);
        this.ticket.setPrice(this.ticket.calculateCost(endTime));
        this.ticket.setParkingSpotID("");
        this.ticket = null;
  }
  
  public String getVehicleID(){
    return Vehicleid;
  }
  
  public void setVehicleID(String Vehicleid){
  this.Vehicleid = Vehicleid;
  }
  
    public String getVehicleType(){
    return VehicleType;
  }
  
  public void setVehicleType(String VehicleType){
  this.VehicleType = VehicleType;
  }
  public Ticket getTicket() {
        return ticket;
  }

  public void setTicket(Ticket ticket) {
        this.ticket = ticket;
  }
  
}