package coe528;

import java.util.ArrayList;

/**
 * Overview: 
 * A customer is an immutable object. The responsibility of the class is to 
 * purchase a parking ticket which will be stored in the Ticket class. The ticket will
 * then be paid depending on the type of vehicle that was parked there, based on the 
 * ParkingSpots class.  
 */

public class Customer extends User {
   //Ticket array for storing tickets added by users and ticket id
    private int id;
    private ArrayList<Ticket> tickets;
    
    //Abstraction Function:
    //AF(bob) = a customer, c, such that 
    //bob.getNumber() = c.getNumber()
    //(bob.getPrice() = Credit || bob.getPrice() = cash
    //
    //Representation Invariant:
    //All customers are able to access the multi-floor parking application
    //in order to purchase and pay their ticket using either credit or cash
    
    public Customer(int id ,String name){
        super(name,"","");
        this.id=id;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * @Requires ticket
     * @Modifies tickets[]
     * @Effects This method adds a ticket to the ticket array tickets[] when 
     * the user buys a parking ticket
     */
    
    public void PurchaseTicket(Ticket ticket) {
        this.tickets.add(ticket);
    }
    
    /**
     * @Requires ticket
     * @Modifies payment
     * @Effects This method checks if the parking ticket is paid for correctly
     */ 
    
    public boolean PayTicket(Ticket ticket) {
        double payment = 0;
        payment = ticket.calculateCost(ticket.getEndTime());
        if(payment == ticket.getPrice()){
            return true;
        }else{
            return false;
        }
    }
}

