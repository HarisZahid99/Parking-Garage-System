package coe528;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;

public class Ticket {
    private int startTime, endTime;
    private int number;
    private double price;
    private String vType, parkingSpotID;
    private Floor floor;
    private Customer customer;
    
    //test
    public Ticket(Floor floor, int startTime, Customer customer, String vType, String parkingSpotID){
        this.startTime = (int)Math.floor(Math.random()*9);
        this.endTime = (int)Math.floor(Math.random()*9)+10;
        this.floor= floor;
        this.price = -1;
        this.vType = vType;
        this.customer = customer;
        this.parkingSpotID = parkingSpotID;
        
        this.number = (int) Math.floor(Math.random() * 900000000) + 100000000; 
    }
    
  //Here we are putting the floor number, startTime, Vehicle type, amount paid and parkingSpotID in to the variables so it can be used later.
  //We are also checking if a valid startTime is entered and making a random 10 digit number for the ticket being made.  
  /*public Ticket(Floor floor, int startTime, Customer customer, String vType, String parkingSpotID){
        if (startTime < 0 || startTime > 23){
            throw new IllegalArgumentException("Integer must be between 0 and 23");
        }
    File ticketsFolder = new File("Tickets");
        String[] ticketsFileList = ticketsFolder.list();
        this.number = (int) Math.floor(Math.random() * 900000000) + 100000000; 
        while(Arrays.asList(ticketsFileList).contains(Long.toString(this.number))){ 
            this.number = (int) Math.floor(Math.random() * 900000000) + 100000000; 
        }
        this.startTime = startTime;
        this.endTime = -1;
        this.floor= floor;
        this.price = -1;
        this.vType = vType;
        this.customer = customer;
        this.parkingSpotID = parkingSpotID;
        Ticket.SaveFile(this);
        
  }
        //Making file for the ticket  
       public static void SaveFile(Ticket ticket){
        File oldFile = new File("Tickets" + File.separatorChar + ticket.number);
        oldFile.delete();
        try{
            FileOutputStream fileOut = new FileOutputStream("Tickets" + File.separatorChar + ticket.number);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(ticket);
            out.close();
            fileOut.close();
        } catch (IOException i){
            i.printStackTrace();
        }
    }*/
        //Calculating costs depending on the endTime for the ticket. In the end it returns the change left from paying the cost  
        public double calculateCost(int endTime){
        int cost=0,timeStayed = endTime - this.startTime;
        if(timeStayed >= 1){
            cost += 4;
        }
        if(timeStayed >= 2){
            cost += 3.5;
        }
        if(timeStayed >= 3){
            cost += 3.5;
        }
        if(timeStayed >= 4){
            cost += (timeStayed-3)*2.5;
        }
        return cost;
          
}
          
    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
        //Ticket.SaveFile(this);
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
       // Ticket.SaveFile(this);
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
        //Ticket.SaveFile(this);
    }

    public Floor getFloor() {
        return floor;
    }

    public void setFloor(Floor floor) {
        this.floor = floor;
        //Ticket.SaveFile(this);
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
        //Ticket.SaveFile(this);
    }

    public String getVehicleType() {
        return vType;
    }

    public void setVehicleType(String vehicleType) {
        this.vType = vehicleType;
        //Ticket.SaveFile(this);
    }
    
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
        //Ticket.SaveFile(this);
    }

    public String getParkingSpotID() {
        return parkingSpotID;
    }

    public void setParkingSpotID(String parkingSpotID) {
        this.parkingSpotID = parkingSpotID;
        //Ticket.SaveFile(this);
    }
          
}
