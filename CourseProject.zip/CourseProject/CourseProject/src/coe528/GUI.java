package coe528;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class GUI extends Application {
    
    Stage window;
    Scene home, login, manager, customer;
    Scene ticket, spots, payment;
    Scene deletes, modifys;
    ListView<Integer> root;
    ListView<Integer> root2;
    //ListView<String> tickets;
    ListView<String> vtype;
    ListView<String> mtype;
    ObservableList<Integer> ticketID = FXCollections.observableArrayList();
    //ArrayList<Integer> ticketID = new ArrayList<>();
    ArrayList<Ticket> ticketL = new ArrayList<>();
    int id = 0;
    int floorNum = 0;
    int rNum = 0;
    int hNum = 0;
    int eNum = 0;
    int fMax = 0;

    public GUI() {
        this.root = new ListView<>(ticketID);
        this.root2 = new ListView<>(ticketID);
    }
    
    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        
        //Home Elements
        Button mb = new Button("Manager");
        mb.setPrefSize(200, 100);
        mb.setOnAction(e -> window.setScene(login));
        Button cb = new Button("Customer");
        cb.setPrefSize(200, 100);
        cb.setOnAction(e -> window.setScene(customer));
        
        //Home Scene
        VBox w = new VBox(50);
        w.setAlignment(Pos.CENTER);
        w.getChildren().addAll(mb, cb);
        home = new Scene(w, 800, 600);
        
        //Login Elements
        Label ll = new Label("Login");
        Label unl = new Label("Username");
        Label pwl = new Label("Password");
        TextField untf = new TextField();
        TextField pwtf = new TextField();
        Button lb = new Button("Login");
        Button back = new Button("Home");
        back.setOnAction(e -> window.setScene(home));
        lb.setOnAction(e -> login(untf.getText(), pwtf.getText()));
       
        //Login Scene
        VBox l = new VBox(50);
        l.setAlignment(Pos.CENTER);
        l.getChildren().addAll(ll, unl, untf, pwl, pwtf, lb, back);
        login = new Scene(l, 800, 600);
        
        //Manager Elements
        Label manage = new Label("Parking Ticket Management");
        root2.getItems().addAll();
        mtype = new ListView<>();
        mtype.getItems().addAll("Compact", "Large", "Handicapped", "Motorcycle", "Electric");
        Button logout = new Button("Logout");
        logout.setPrefSize(200, 100);
        logout.setOnAction(e -> window.setScene(home));
        Button modify = new Button("Modify");
        modify.setPrefSize(200, 100);
        modify.setOnAction(e -> modify(root2.getSelectionModel().getSelectedItem().toString(), mtype.getSelectionModel().getSelectedItem())); //modify method below
        Button delete = new Button("Delete");
        delete.setPrefSize(200, 100);
        delete.setOnAction(e -> delete(root2.getSelectionModel().getSelectedItem().toString())); //delete method below
        
        //Manager Scene
        HBox controls = new HBox(50);
        controls.setAlignment(Pos.CENTER);
        controls.getChildren().addAll(modify, delete, logout);
        VBox m = new VBox(50);
        m.setAlignment(Pos.CENTER);
        m.getChildren().addAll(manage, root2, mtype, controls);
        manager = new Scene(m, 800, 600);
        
        //Customer Elements
        Button collect = new Button("Collect");
        collect.setPrefSize(200, 100);
        Button back2 = new Button("Home");
        back2.setOnAction(e -> window.setScene(home));
        collect.setOnAction(e -> window.setScene(ticket)); //collect method below
        Button pay = new Button("Pay");
        pay.setPrefSize(200, 100);
        pay.setOnAction(e -> window.setScene(payment)); //pay method below
        
        //Customer Scene
        VBox c = new VBox(50);
        c.setAlignment(Pos.CENTER);
        c.getChildren().addAll(collect, pay, back2);
        customer = new Scene(c, 800, 600); 
        
        //Ticket Elements
        Label name = new Label("Enter your name");
        TextField ntf = new TextField();
        vtype = new ListView<>();
        vtype.getItems().addAll("Compact", "Large", "Handicapped", "Motorcycle", "Electric");
        Button print = new Button("Print");
        print.setPrefSize(200, 100);
        print.setOnAction(e -> ticket(ntf.getText(), vtype.getSelectionModel().getSelectedItem()));
        
        //Ticket Scene
        VBox t = new VBox(50);
        t.setAlignment(Pos.CENTER);
        t.getChildren().addAll(name, ntf, vtype, print);
        ticket = new Scene(t, 800, 600);
        
        //Payment Elements
        root.getItems().addAll();
        Label unpaid = new Label("Unpaid Parking Tickets");
        Label method = new Label("Select Method of Payment");
        Button cash = new Button("Cash");
        cash.setPrefSize(200, 100);
        cash.setOnAction(e -> paying(0,root.getSelectionModel().getSelectedItem().toString()));
        Button card = new Button("Credit Card");
        card.setPrefSize(200, 100);
        card.setOnAction(e -> paying(1,root.getSelectionModel().getSelectedItem().toString()));
        
        //Payment Scene
        VBox p = new VBox(50);
        p.setAlignment(Pos.CENTER);
        p.getChildren().addAll(unpaid, root, method, cash, card);
        payment = new Scene(p, 800, 600);
        
        //Window
        window.setScene(home);
        window.setTitle("Parking Ticket");
        window.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public boolean login(String user, String pass) {
        if(user.equals("admin") && pass.equals("admin")){
            window.setScene(manager);
            return true;
        }else{
            return false;
        }
    }

    private void modify(String num, String type){
        //System.out.println(num + type);
        for(int i=0; i < ticketID.size(); i++){
            if(num.equals(ticketID.get(i).toString())){
                ticketL.get(i).setVehicleType(type);
                System.out.println(ticketL.get(i).getVehicleType());
                System.out.println(num+" modified");
                break;
            }
        } 
        window.setScene(home);
    }
    
    private void delete(String dnum) {
       for(int i=0; i < ticketID.size(); i++){
            if(dnum.equals(ticketID.get(i).toString())){
                System.out.println(dnum+" deleted");
                ticketID.remove(i);
                ticketL.remove(i);
            }
        }
       window.setScene(home);
    }

    private void collect() {
        window.setScene(spots);
    }

    private void ticket(String name, String type) {
        ArrayList<Customer> customerL = new ArrayList<>();
        String ptype;
        Floor floor = new Floor(floorNum);
        customerL.add(new Customer(id++, name));

        //vtype 
        if(type.equals("Handicapped") || type.equals("Electric")){
            ptype = type;
        }else{
            ptype = "Regular";
        }
        
        //floor
        if(type.equals("Handicapped")){
            floorNum = hNum;
            hNum++;
        }else if(type.equals("Electric")){
            floorNum = eNum;
            eNum++;
        }else{
            if(rNum < 5){
                rNum++;
                if(hNum != eNum){
                    floorNum = fMax;
                }
            }else if(rNum == 5){
                floorNum++;
                fMax++;
                rNum = 0;
            }
        }
        
        ticketL.add(new Ticket(new Floor(floorNum), 0, new Customer(id++, name), type, ptype));
        //System.out.println(ticketL.get(0).getNumber());
        //System.out.println(ticketL.get(ticketL.size()-1).getNumber());
        ticketID.add((int)ticketL.get(ticketL.size()-1).getNumber());
        window.setScene(home);
        //System.out.println(ticketID.get(ticketID.size()-1));
        
    }

    private void paying(int paym, String tnum) {
        if(paym == 0){
            System.out.println("Insert cash..");
        }else{
            System.out.println("Insert card..");
        }
        
        //search
        for(int i=0; i < ticketID.size(); i++){
            if(tnum.equals(ticketID.get(i).toString())){
                System.out.println("$"+fee(ticketL.get(i).getStartTime(),ticketL.get(i).getEndTime()));
                System.out.println(tnum+" paid");
                ticketID.remove(i);
                ticketL.remove(i);
            }
        } 
        window.setScene(home);
    }
    
    private double fee(int start, int end){
        int time = end - start;
        if(time == 1){
            return 4.0;
        }else if(time <= 3){
            return ((time-1)*3.5) + 4.0;
        }else{
            return((time-3)*2.5) + 11.0; 
        }
    }
    
}
