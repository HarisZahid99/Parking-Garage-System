package coe528;

public class User {
    
  public String name;
  public String userName;
  public String pass;
  
 //Adding the name, userName and password into variables to use later 
  public User(String name, String userName, String pass){
    this.name = name;
    this.userName = userName;
    this.pass = pass;
   }
  
  
  
  //Getters and Setters methods
  
  public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return pass;
    }

    public void setPassword(String pass) {
        this.pass = pass;
    }

}

