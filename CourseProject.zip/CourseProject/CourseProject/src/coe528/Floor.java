package coe528;

import java.util.ArrayList;

public class Floor {
    
  public int level;
    public ParkingSpots[] pSpot; 
     
    
    //Here we are initializing each spots with its information. eg First parking spot is regular and last spot is for electric. 
    public Floor(int level){
       
        this.level = level;
        this.pSpot = new ParkingSpots[8];
        pSpot[0] = new ParkingSpots("Regular1", "Regular");
        pSpot[1] = new ParkingSpots("Regular2", "Regular");
        pSpot[2] = new ParkingSpots("Regular3", "Regular");
        pSpot[3] = new ParkingSpots("Regular4", "Regular");
        pSpot[4] = new ParkingSpots("Regular5", "Regular");
        pSpot[5] = new ParkingSpots("Regular6", "Regular");
        pSpot[6] = new ParkingSpots("Handicapped1", "Handicapped");
        pSpot[7] = new ParkingSpots("Electric1", "Electric");
      
    }
  
      // checking array ParkingSpots for empty cells.
   public ParkingSpots[] getEmptySpots(String parkingSpotType){
        ArrayList<ParkingSpots> emptySpots = new ArrayList();
        for (ParkingSpots spot : this.pSpot){
            if (spot.getTicket()== null && spot.getVehicleType().equalsIgnoreCase(parkingSpotType)){
                emptySpots.add(spot);
            }
        }
        return emptySpots.toArray(new ParkingSpots[emptySpots.size()]);
    }
      
     //Filling in the empty spot with a spot 
     public ParkingSpots getParkingSpot(String id){
        for (ParkingSpots spot : this.pSpot){
            if (spot.getVehicleID().equalsIgnoreCase(id)){
                return spot;
            }
        }
        return null;
    }
      
   public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
  
   public ParkingSpots[] getParkingSpot() {
        return pSpot;
    }

    public void setParkingSpot(ParkingSpots[] pSpot) {
        this.pSpot = pSpot;
    } 
}
