package coe528;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Manager extends User{
  private static boolean Login = false;
  public static final int MAX_FLOOR = 4;
  public static final int MAX_SPOTS = 8;
  Floor[] floor; 
  private ArrayList<Ticket> tickets;
   
          public Manager()  throws Exception{
        super("manager","admin","admin");
        if(!Manager.Login){
            Manager.Login = true;
            floor = new Floor[Manager.MAX_FLOOR]; 
            for(int i=0; i<Manager.MAX_FLOOR; i++){
                floor[i] = new Floor(i+1);
            }
            Files.createDirectories(Paths.get("Tickets"));
            tickets = new ArrayList<>();
            File directory = new File("Tickets");
            String[] ticketNumbers = directory.list();
            for (String ticketNumber : ticketNumbers){
                try{
                    FileInputStream fileIn = new FileInputStream("Tickets" + File.separatorChar + ticketNumber);
                    ObjectInputStream in = new ObjectInputStream(fileIn);
                    tickets.add((Ticket)in.readObject());
                    if(tickets.get(tickets.size()-1).getEndTime() == -1){
                        Ticket temp = tickets.get(tickets.size()-1);
                        floor[temp.getFloor().getLevel()].getParkingSpot(temp.getParkingSpotID()).setTicket(tickets.get(tickets.size()-1));
                    }
                    in.close();
                    fileIn.close();
                } catch (IOException i) {
                   i.printStackTrace();
                   return;
                } catch (ClassNotFoundException c) {
                   System.out.println("Ticket class not found");
                   c.printStackTrace();
                   return;
                }
            }
            
        }else{
            throw new Exception("Manager was already created. You cannot have more than 1 manager");
        }
    }
  
          
  public boolean delTicket(long number){
        for(Ticket ticket : this.tickets){
            if(ticket.getNumber() == number){
                this.tickets.remove(ticket);
                File file = new File("Tickets" + File.separatorChar + number);
                if (file.delete()){
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }
    
    public boolean addFloor(Floor floor){
        for (int i=0; i<this.floor.length; i++){
            if(this.floor[i] == null){
                this.floor[i] = floor;
                return true;
            }
        }
        return false;
    }
    
    public boolean addTicket(Ticket ticket){
        this.tickets.add(ticket);
        if(tickets.get(tickets.size()-1) == ticket){
            return true;
        }else{
            return false;
        }
    }
  
  
  
  //getter and setter methods
    
    public static int getMAX_FLOORS(){
        return Manager.MAX_FLOOR;
    }
    
    public static int getMAX_SPOTS(){
        return Manager.MAX_SPOTS;
    }

    public static boolean isCreated() {
        return Login;
    }

    public static void setCreated(boolean created) {
        Manager.Login = created;
    }

    public Floor[] getFloors() {
        return floor;
    }

    public void setFloors(Floor[] floors) {
        this.floor = floors;
    }

    public ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(ArrayList<Ticket> tickets) {
        this.tickets = tickets;
    }
  
    
    //Main code 
    
    public static void main(String args[]) throws Exception{
    Manager man = new Manager();
    Ticket ticket_new = new Ticket(new Floor(1), 23, new Customer(0,"aeqwew"), "Car", "Regular1");
        for(Ticket ticket : man.tickets){
            System.out.println(ticket.getNumber());
        }
        System.out.println(man.floor[1].getParkingSpot("Regular1").getTicket());
    }
}